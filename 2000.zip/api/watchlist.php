<?php
error_reporting(0);

// Enable CORS for cross-origin access
header('Access-Control-Allow-Origin: *'); // Adjust to your frontend origin if needed
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Database connection
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = "";    // Replace with your database password
$dbname = "filmkitchen"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => false, "message" => "Database connection failed"]));
}

// Get parameters from GET request
$movieid = isset($_GET['movieid']) ? $_GET['movieid'] : null;
$token = isset($_GET['token']) ? $_GET['token'] : null;
$mode = isset($_GET['mode']) ? $_GET['mode'] : null;

if (!$token) {
    echo json_encode(["status" => false, "message" => "Token is required"]);
    exit;
}

$stmt = $conn->prepare("SELECT userid FROM users WHERE token = ?");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => false, "message" => "Invalid or expired token"]);
    $stmt->close();
    $conn->close();
    exit;
}

$row = $result->fetch_assoc();
$userid = $row['userid'];
$stmt->close();

if ($mode == "chk") {
    $stmt = $conn->prepare("SELECT * FROM watchlist WHERE movieid = ? AND userid = ?");
    $stmt->bind_param("ss", $movieid, $userid);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo json_encode(["status" => true, "message" => "Movie is in watchlist"]);
    } else {
        echo json_encode(["status" => false, "message" => "Movie not in watchlist"]);
    }
    $stmt->close();
} elseif ($mode == "add") {
    $stmt = $conn->prepare("INSERT INTO watchlist (movieid, userid) VALUES (?, ?)");
    $stmt->bind_param("ss", $movieid, $userid);
    if ($stmt->execute()) {
        echo json_encode(["status" => true, "message" => "Added to watchlist"]);
    } else {
        echo json_encode(["status" => false, "message" => "Error adding to watchlist"]);
    }
    $stmt->close();
} elseif ($mode == "rmv") {
    $stmt = $conn->prepare("DELETE FROM watchlist WHERE movieid = ? AND userid = ?");
    $stmt->bind_param("ss", $movieid, $userid);
    if ($stmt->execute()) {
        echo json_encode(["status" => true, "message" => "Removed from watchlist"]);
    } else {
        echo json_encode(["status" => false, "message" => "Error removing from watchlist"]);
    }
    $stmt->close();
} elseif ($mode == "get") {
    $stmt = $conn->prepare("SELECT movieid FROM watchlist WHERE userid = ?");
    $stmt->bind_param("s", $userid);
    $stmt->execute();
    $result = $stmt->get_result();
    $watchlist = [];
    while ($row = $result->fetch_assoc()) {
        $watchlist[] = $row['movieid'];
    }
    echo json_encode(["status" => true, "watchlist" => $watchlist]);
    $stmt->close();
} else {
    echo json_encode(["status" => false, "message" => "Invalid mode"]);
}

$conn->close();
?>