<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT');

$conn = new mysqli("localhost", "root", "", "filmkitchen");

if ($conn->connect_error) {
    die(json_encode(["status" => false, "message" => "Database connection failed"]));
}

$method = $_SERVER['REQUEST_METHOD'];
$token = $_GET['token'] ?? '';
$movie_id = $_GET['movieid'] ?? '';
$review_text = $_GET['review'] ?? ($_POST['review'] ?? '');
$mode = $_GET['mode'] ?? '';

if (empty($movie_id)) {
    echo json_encode(["status" => false, "message" => "Missing movie ID"]);
    exit;
}

if ($method === 'GET' && $mode === 'all') {
    // Fetch all reviews for the movie
    $stmt = $conn->prepare("SELECT u.name, r.review_text FROM reviews r JOIN users u ON r.user_id = u.userid WHERE r.movie_id = ?");
    $stmt->bind_param("i", $movie_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $reviews = [];
    while ($row = $result->fetch_assoc()) {
        $reviews[] = $row;
    }
    echo json_encode(["status" => true, "reviews" => $reviews]);
} elseif ($method === 'GET' && $token) {
    // Fetch user's review
    $stmt = $conn->prepare("SELECT userid FROM users WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        echo json_encode(["status" => false, "message" => "Invalid token"]);
        exit;
    }

    $user_id = $user['userid'];
    $stmt = $conn->prepare("SELECT review_text FROM reviews WHERE user_id = ? AND movie_id = ?");
    $stmt->bind_param("ii", $user_id, $movie_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        echo json_encode(["status" => true, "review" => $row['review_text']]);
    } else {
        echo json_encode(["status" => false, "message" => "No review found"]);
    }
} elseif ($method === 'POST' || ($method === 'GET' && $review_text)) {
    $stmt = $conn->prepare("SELECT userid FROM users WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        echo json_encode(["status" => false, "message" => "Invalid token"]);
        exit;
    }

    $user_id = $user['userid'];
    $stmt = $conn->prepare("SELECT id FROM reviews WHERE user_id = ? AND movie_id = ?");
    $stmt->bind_param("ii", $user_id, $movie_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(["status" => false, "message" => "You have already reviewed this movie"]);
    } else {
        $stmt = $conn->prepare("INSERT INTO reviews (user_id, movie_id, review_text) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $user_id, $movie_id, $review_text);
        if ($stmt->execute()) {
            echo json_encode(["status" => true, "message" => "Review submitted successfully"]);
        } else {
            echo json_encode(["status" => false, "message" => "Failed to submit review"]);
        }
    }
} elseif ($method === 'PUT') {
    $stmt = $conn->prepare("SELECT userid FROM users WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        echo json_encode(["status" => false, "message" => "Invalid token"]);
        exit;
    }

    $user_id = $user['userid'];
    $stmt = $conn->prepare("UPDATE reviews SET review_text = ? WHERE user_id = ? AND movie_id = ?");
    $stmt->bind_param("sii", $review_text, $user_id, $movie_id);
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        echo json_encode(["status" => true, "message" => "Review updated successfully"]);
    } else {
        echo json_encode(["status" => false, "message" => "Failed to update review"]);
    }
}

$stmt->close();
$conn->close();
?>