-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 28, 2025 at 01:32 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `filmkitchen`
--

-- --------------------------------------------------------

--
-- Table structure for table `favourites`
--

CREATE TABLE `favourites` (
  `userid` int NOT NULL,
  `movieid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `favourites`
--

INSERT INTO `favourites` (`userid`, `movieid`) VALUES
(2, 811941),
(3, 857598),
(7, 857598),
(8, 811941),
(3, 811941),
(9, 811941);

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `userid` int NOT NULL,
  `movieid` int NOT NULL,
  `rating` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`userid`, `movieid`, `rating`) VALUES
(2, 1418436, 3),
(3, 1418436, 3),
(9, 811941, 3);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `movie_id` int NOT NULL,
  `review_text` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `movie_id`, `review_text`, `created_at`, `updated_at`) VALUES
(1, 2, 1418436, 'Hello', '2025-02-28 00:31:30', '2025-02-28 00:31:38'),
(2, 9, 811941, 'Good Movie', '2025-02-28 01:13:30', '2025-02-28 01:13:30');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `name`, `email`, `password`, `token`) VALUES
(1, 'JATHIN TEJA', 'jathincheeli@gmail.com', 'Jathin@123', '12345678912345678912345678912345'),
(2, 'Mohan', 'mohanmalladi@gmail.com', '46d9785f4401ac99cb84be5bacff1725', 'b008032b573fe37fc222c62e0e22d85a'),
(3, 'Venky', 'venkateshkanchi@gmail.com', '0766b9e7257698ca91fb6bf870d5a1d8', '591788ac61dd0a42e330b45356915f80'),
(5, '', 'sunnnyleone12@gmail.com', 'c848b6ccf5b251a42d631c3c4aca1d36', '21c4f412deccbb2d7f624ad688617e83'),
(6, '', 'manikanta@gmail.com', 'b2d3c247a452fa0926f21e7617bddbd3', NULL),
(7, '', 'manibhai@gmail.com', 'b2d3c247a452fa0926f21e7617bddbd3', '5dc96f3cfbbd75bceeb0c6cec697ed17'),
(8, '', 'abcd@gmail.com', '18bbba17831f22318a2cefb507d51a03', 'eb746b28762eda8e722636203b9d991a'),
(9, '', 'abcdef@gmail.com', '46d9785f4401ac99cb84be5bacff1725', '7bbf1dc2e91603e4b09360e82de0e72e');

-- --------------------------------------------------------

--
-- Table structure for table `watchlist`
--

CREATE TABLE `watchlist` (
  `userid` int NOT NULL,
  `movieid` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `watchlist`
--

INSERT INTO `watchlist` (`userid`, `movieid`) VALUES
(2, 811941),
(3, 857598),
(7, 857598),
(8, 811941),
(9, 811941);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_review` (`user_id`,`movie_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`userid`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
