<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$conn = new mysqli("localhost", "root", "", "filmkitchen");

if ($conn->connect_error) {
    die(json_encode(["status" => false, "message" => "Database connection failed"]));
}

$token = $_GET['token'] ?? '';
$movieid = $_GET['movieid'] ?? '';
$rating = $_GET['rating'] ?? '';
$mode = $_GET['mode'] ?? '';

$stmt = $conn->prepare("SELECT userid FROM users WHERE token = ?");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo json_encode(["status" => false, "message" => "Invalid token"]);
    exit;
}

$userid = $user['userid'];

if ($mode === 'check') {
    // Fetch user's rating
    $stmt = $conn->prepare("SELECT rating FROM rating WHERE userid = ? AND movieid = ?");
    $stmt->bind_param("ii", $userid, $movieid);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        echo json_encode(["status" => true, "rating" => $row['rating']]);
    } else {
        echo json_encode(["status" => false, "message" => "No rating found"]);
    }
} else {
    // Check if rating already exists
    if (empty($token) || empty($movieid)) {
        echo json_encode(["status" => false, "message" => "Missing parameters"]);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT userid FROM rating WHERE userid = ? AND movieid = ?");
    $stmt->bind_param("ii", $userid, $movieid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $sql = "UPDATE rating SET rating = $rating WHERE userid = $userid AND movieid = $movieid;";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => true, "message" => "Rating Updated"]);
          } else {
            echo json_encode(["status" => false, "message" => $conn->error]);
          }    
    
    } else {
        // Insert new rating
        $stmt = $conn->prepare("INSERT INTO rating (userid, movieid, rating) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $userid, $movieid, $rating);
        if ($stmt->execute()) {
            echo json_encode(["status" => true, "message" => "Rating submitted successfully"]);
        } else {
            echo json_encode(["status" => false, "message" => "Failed to submit rating"]);
        }
    }
}

$stmt->close();
$conn->close();
?>