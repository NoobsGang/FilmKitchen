<?php
error_reporting(0);
// Enable CORS for cross-origin access
header('Access-Control-Allow-Origin: *'); // Adjust to your frontend origin if needed
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Database connection
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = "";    // Replace with your database password
$dbname = "filmkitchen"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);
if(!$conn){
    $error = "Unkown Server Side Error Occurred !!";
    die(json_encode(["status" => false,"error" => $error]));
}
else{
    $data = json_decode(file_get_contents('php://input'),true);
    $email = $data['email'];
    if($email == ""){
        die(json_encode(["status" => false,"error" => "EMAIL NOT PROVIDED"]));
    }
    //$email = "jathincheeli@gmail.com"; // Example user input
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    if( $result->num_rows > 0) {
                echo json_encode(["status" => false, "error" => "USER ALREADY EXIST"]);    }
    else {
        $password = md5($data['password']);
        $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => true, "message" => "USER CREATED"]);
          } else {
            echo json_encode(["status" => false, "error" => $conn->error]);
          }
           
    }
}
?>