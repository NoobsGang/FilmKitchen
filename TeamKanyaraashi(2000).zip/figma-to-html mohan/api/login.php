<?php
error_reporting(0);
// Enable CORS for cross-origin access
header('Access-Control-Allow-Origin: *'); // Adjust to your frontend origin if needed
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Database connection
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = "";    // Replace with your database password
$dbname = "filmkitchen"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);
if(!$conn){
    $error = "Unkown Server Side Error Occurred !!";
    die(json_encode(["success" => false,"error" => $error]));
}
else{
    $data = json_decode(file_get_contents('php://input'),true);
    $email = $data['email'];
    // $email = "venkateshkanchi@gmail.com";
    if($email == ""){
        die(json_encode(["success" => false,"error" => "EMAIL NOT PROVIDED"]));
    }
    //$email = "jathincheeli@gmail.com"; // Example user input
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    if( $result->num_rows > 0) {
        $password = md5($data['password']);
        $database = $result->fetch_assoc();
        if($password == $database['password']){
            $token = md5(uniqid());
            $sql = "UPDATE users SET token = '$token' WHERE email = '$email';";
            if ($conn->query($sql) === TRUE) {
                echo json_encode(["success" => true, "error" => "Login Successfull","token"=>"$token"]);
              } else {
                echo json_encode(["success" => false, "error" => $conn->error]);
              }    
        }
        else{
            echo json_encode(["success" => false, "error" => "Wrong Password"]);
        }
    }
    else {
        echo json_encode(["success" => false, "error" => "Email Not Registered"]);           
    }
}
?>